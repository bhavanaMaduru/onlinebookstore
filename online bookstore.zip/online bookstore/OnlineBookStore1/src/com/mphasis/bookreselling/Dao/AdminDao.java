package com.mphasis.bookreselling.Dao;

import java.util.List;

import com.mphasis.bookreslling.bean.Admin;
import com.mphasis.bookreslling.bean.Registration;

public interface AdminDao {
	
	public void create(Admin a);
	public  List<Admin> read(int userid) ;
	
	public void update(int userid, String status);
	public  void delete(int userid);
}
