package com.mphasis.bookreslling.bo;

import java.util.List;

import com.mphasis.bookreslling.bean.Registration;
import com.mphasis.bookreselling.Dao.RegistrationDao;
import com.mphasis.bookreselling.Dao.RegistrationDaoImpl;

public class RegistrationBo {

	public void create(Registration registration) {
		RegistrationDao registrationDao=new RegistrationDaoImpl();
	    registrationDao.create(registration);
		
	}

	public  List<Registration> read(int sno) {
		RegistrationDao registrationDao=new RegistrationDaoImpl();
		List<Registration> RegistrationList=registrationDao.read(sno);
		return RegistrationList;
	}
	
	public  void update (int sno,String emailid) {
		RegistrationDao registrationDao=new RegistrationDaoImpl();
		registrationDao.update(sno,emailid);
		
	}

	public   void delete(int sno) {
		RegistrationDao registrationDao=new RegistrationDaoImpl();
		registrationDao.delete(sno);
		
	}

}


