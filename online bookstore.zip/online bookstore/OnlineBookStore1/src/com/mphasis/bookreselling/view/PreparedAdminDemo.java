package com.mphasis.bookreselling.view;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.mphasis.bookreslling.bean.Admin;
import com.mphasis.bookreslling.bo.AdminBo;

public class PreparedAdminDemo {
	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		int userid,quantity;
		
		String username,status,transaction, choice;
		int ch;
		AdminBo adminBo = new AdminBo();
		List<Admin> list = new ArrayList<>();
		do {
			System.out.println("CRUD Application");
			System.out.println("1.Adduser \n 2.userdetatils \n 3.updateusers \n 4.deleteuser4");
			System.out.println("Enter choice");
			ch = scanner.nextInt();
		
			switch (ch) {
			case 1:
				System.out.println("Enter Admin details userid,username,quantity,status,transaction");
				userid= scanner.nextInt();
				username = scanner.next();
			    quantity = scanner.nextInt();
			    status = scanner.next();
				transaction = scanner.next();
			    Admin admin = new Admin();
			
				admin.setUserid(userid);
				admin.setUsername(username);
				admin.setQuantity(quantity);
			    admin.setStatus(status);
			    admin.settransaction(transaction);
			    
				adminBo.create(admin);

				break;
			case 2:
				System.out.println("Enter userid");
				userid = scanner.nextInt();

				list = adminBo.read( userid);
				list.forEach(a -> System.out.println(a));		

				break;

			case 3:
				System.out.println("Enter userid and status to update");
				userid = scanner.nextInt();
                status=scanner.next();
				adminBo.update(userid,status);

				break;
			case 4:
				System.out.println("Enter userid to delete");
				userid = scanner.nextInt();

				adminBo.delete(userid);

				break;
			default:
				System.out.println("Invalid choice");
			}

			System.out.println("want to continue");
			choice = scanner.next();
		} while (choice.equals("yes"));

	}
}

