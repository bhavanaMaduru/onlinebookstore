package com.mphasis.bookreselling.view;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.mphasis.bookreslling.bean.Book;
import com.mphasis.bookreslling.bo.BookBo;

public class PreparedBookDemo {
	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		int bookid,price,quantity;
		
		String bookname,author,addtocart, choice;
		int ch;
		BookBo bookBo = new BookBo();
		List<Book> list = new ArrayList<>();
		do {
			System.out.println("CRUD Application");
			System.out.println("1.ADD BOOKS \n 2.VIEW BOOKS \n 3.UPDATEBOOKS \n 4.DELETE BOOKS");
			System.out.println("Enter choice");
			ch = scanner.nextInt();
		
			String status;
			switch (ch) {
			case 1:
				System.out.println("Enter Book details bookname,bookid,author,price,quantity,status,addtocart");
				bookname = scanner.next();
				bookid = scanner.nextInt();
			    author = scanner.next();
			    price = scanner.nextInt();
			    quantity = scanner.nextInt();
			    status = scanner.next();
			    addtocart = scanner.next();
			    
			    Book book = new Book();
			
				book.setbookname(bookname);
				book.setbookid(bookid);
				book.setauthor(author);
			    book.setprice(price);
			    book.setquantity(quantity);
			    book.setstatus(status);
			    book.setaddtocart(addtocart);
			    
				bookBo.create(book);

				break;
			case 2:
				System.out.println("Enter bookid");
				bookid = scanner.nextInt();

				list = bookBo.read( bookid);
				list.forEach(b -> System.out.println(b));		

				break;

			case 3:
				System.out.println("Enter bookid and bookname to update");
				bookid = scanner.nextInt();
                author=scanner.next();
				bookBo.update(bookid,author);

				break;
			case 4:
				System.out.println("Enter Bookid remove book");
				bookid = scanner.nextInt();

				bookBo.delete(bookid);

				break;
			default:
				System.out.println("Invalid choice");
			}

			System.out.println("want to continue");
			choice = scanner.next();
		} while (choice.equals("yes"));

	}
}

