package com.mphasis.bookreselling.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mphasis.bookreslling.bean.Book;
import com.mphasis.bookreselling.util.DBHandler;

public class BookDaoImpl implements BookDao{
	private String bookname;

	public void create(Book b) {
		PreparedStatement ps = null;
		Connection conn = null;
		try {
			conn = DBHandler.getConnection();
			// conn.setAutoCommit(false);
			String query = "insert into books(bookname,bookid,author,price,quantity,status,addtocart) values(?,?,?,?,?,?,?)";
			ps = conn.prepareStatement(query);
			ps.setString(1, b.getbookname());
			ps.setInt(2, b.getbookid());
			ps.setString(3, b.getauthor());
			ps.setInt(4, b.getprice());
			ps.setInt(5, b.getquantity());
			ps.setString(6, b.getstatus());
			ps.setString(7, b. getaddtocart());
			
			int rows = ps.executeUpdate();
			System.out.println(rows + "Books Added into list");
			// conn.commit();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
	}

	public List<Book> read(int bookid) {
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<Book> list = new ArrayList<>();
		Book b = null;
		Connection conn = null;
		try {
			conn = DBHandler.getConnection();
			String query = "select * from books where bookid =?";
			ps = conn.prepareStatement(query);
			ps.setInt(1, bookid);
			rs = ps.executeQuery();
			System.out.println("Registration Details" + bookid);
			while (rs.next()) {
				b = new Book();
				b.setbookname(rs.getString("bookname"));
				b.setbookid(rs.getInt("bookid"));
				b.setauthor(rs.getString("author"));
				b.setprice(rs.getInt("price"));
				b.setquantity(rs.getInt("quantity"));
				b.setstatus(rs.getString("status"));
				b.setaddtocart(rs.getString("addtocart"));
				
				list.add(b);
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
		return list;
	}

	public void update(int bookid, String bookname) {
		PreparedStatement ps = null;
		Connection conn = null;
		try {
			conn = DBHandler.getConnection();
			String query = "update Books set bookname=? where bookid=?";
			ps = conn.prepareStatement(query);
			ps.setString(1,bookname);
			ps.setInt(2, bookid);
			int res = ps.executeUpdate();
			System.out.println(res + "Book Author updated");
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}

		finally {
			try {
				conn.close();
			} catch (SQLException e) {

				System.out.println(e.getMessage());
			}
		}
	}

	public void delete(int bookid)  {
		PreparedStatement ps = null;
		Connection conn = null;
		try {
			conn = DBHandler.getConnection();
			String query = "delete from books where bookid=?";
			ps = conn.prepareStatement(query);
			ps.setInt(1, bookid);
			int res = ps.executeUpdate();
			System.out.println(res + " Remove Book Successflly");
		} catch (SQLException e) {

			System.out.println(e.getMessage());
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {

				System.out.println(e.getMessage());
			}
		}

	}
}
