package com.mphasis.bookreselling.Dao;

import java.util.List;

import com.mphasis.bookreslling.bean.Book;

public interface BookDao {
	
	public void create(Book b);
	public  List<Book> read(int bookid) ;
	
	public void update(int bookid, String status);
	public  void delete(int bookid);
}
