package com.mphasis.bookreselling.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mphasis.bookreslling.bean.Admin;
import com.mphasis.bookreslling.bean.Registration;
import com.mphasis.bookreselling.util.DBHandler;

public class AdminDaoImpl implements AdminDao{
	private String username;

	public void create(Admin a) {
		PreparedStatement ps = null;
		Connection conn = null;
		try {
			conn = DBHandler.getConnection();
			// conn.setAutoCommit(false);
			String query = "insert into admin(userid,username,quantity,status,transaction) values(?,?,?,?,?)";
			ps = conn.prepareStatement(query);
			ps.setInt(1, a.getUserid());
			ps.setString(2, a.getUsername());
			ps.setInt(3, a.getQuantity());
			ps.setString(4, a.getStatus());
			ps.setString(5, a.gettransaction());
			
			int rows = ps.executeUpdate();
			System.out.println(rows + "row  inserted");
			// conn.commit();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
	}

	public List<Admin> read(int userid) {
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<Admin> list = new ArrayList<>();
		Admin a = null;
		Connection conn = null;
		try {
			conn = DBHandler.getConnection();
			String query = "select * from admin where userid =?";
			ps = conn.prepareStatement(query);
			ps.setInt(1, userid);
			rs = ps.executeQuery();
			System.out.println("Admin Details" + userid);
			while (rs.next()) {
				a = new Admin();
				a.setUserid(rs.getInt("userid"));
				a.setUsername(rs.getString("username"));
				a.setQuantity(rs.getInt("quantity"));
				a.setStatus(rs.getString("status"));
		
				list.add(a);
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
		return list;
	}

	public void update(int userid,String status) {
		PreparedStatement ps = null;
		Connection conn = null;
		try {
			conn = DBHandler.getConnection();
			String query = "update Admin set status=? where userid=?";
			ps = conn.prepareStatement(query);
			
			ps.setString(1, status);
			ps.setInt(2, userid);
			int res = ps.executeUpdate();
			System.out.println(res + " row updated");
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}

		finally {
			try {
				conn.close();
			} catch (SQLException e) {

				System.out.println(e.getMessage());
			}
		}
	}

	public void delete(int userid)  {
		PreparedStatement ps = null;
		Connection conn = null;
		try {
			conn = DBHandler.getConnection();
			String query = "delete from admin where userid=?";
			ps = conn.prepareStatement(query);
			ps.setInt(1, userid);
			int res = ps.executeUpdate();
			System.out.println(res + " row deleted");
		} catch (SQLException e) {

			System.out.println(e.getMessage());
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {

				System.out.println(e.getMessage());
			}
		}

	}


	}

