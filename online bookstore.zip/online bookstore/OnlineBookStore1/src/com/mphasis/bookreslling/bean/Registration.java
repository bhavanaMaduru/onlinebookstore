
package com.mphasis.bookreslling.bean;

public class Registration {
   private int sno;
   private String firstname;
   private String lastname;
   private String emailid;
   private int phonenumber;
   private String gender;
   private int dob;
   
   
   public int getSno() {
	   return sno;
   }
   public void setSno(int sno) {
	   this.sno = sno;
   }
   public String getFirstname() {
	   return firstname;
   }
   public void setFirstname(String firstname) {
	   this.firstname = firstname;
   }
   public String getlastname() {
	   return lastname;
   }
   public void setLastname(String lastname) {
	   this.lastname = lastname;
   }
   public String getemailid() {
	   return emailid;
   }
   public void setemailid(String emailid) {
	   this.emailid = emailid;
   }
   public int getphonenumber() {
	   return phonenumber;
   }
   public void setphonenumber(int phonenumber) {
	   this.phonenumber = phonenumber;
   }
   public String getgender() {
	   return gender;
   }
   public void setgender(String gender) {
	   this.gender = gender;
   }
   public int getdob() {
	   return dob;
   }
   public void setdob(int dob) {
	   this.dob = dob;
   }
	   
   @Override
	public String toString() {
		return String.format("registration [sno=%s, firstname=%s, lastname=%s, emailid=%s, phonenumber=%s, gender=%s,dob=%s]",
				sno, firstname, lastname,emailid, phonenumber, gender,dob);
	}   
   }
