package com.mphasis.bookreslling.bean;

public class Book {
	private String bookname;
	private int bookid;
	private String author;
	private int price;
	private int quantity;
	private String status;
	private String addtocart;
	
	public String getbookname() {
		return bookname;
	}
public void setbookname(String bookname) {
	this.bookname=bookname;
}
public int getbookid() {
	return bookid;
	
}
public void setbookid(int bookid) {
	this.bookid=bookid;
}
public String getauthor() {
	return author;
}
public void setauthor(String author) {
	this.author=author;
}
public int getprice() {
	return price;
	
}
public void setprice(int price) {
	this.price=price;
}
public int getquantity() {
	return quantity;
	
}
public void setquantity(int quantity) {
	this.quantity=quantity;
}
public String getstatus() {
	return status;
	
}
public void setstatus(String status) {
	this.status=status;
}
public String getaddtocart() {
	return addtocart;
	
}
public void setaddtocart(String addtocart) {
	this.addtocart=addtocart;
}
@Override
public String toString() {
	return String.format("books [bookname=%s, bookid=%s, author=%s, price=%s, quantity=%s, status=%s, addtocart=%s]",
	    bookname,bookid,author,price,quantity,status,addtocart);

}

}
