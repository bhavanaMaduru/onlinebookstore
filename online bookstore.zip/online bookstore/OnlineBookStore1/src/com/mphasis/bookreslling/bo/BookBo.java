package com.mphasis.bookreslling.bo;

import java.util.List;

import com.mphasis.bookreslling.bean.Book;
import com.mphasis.bookreselling.Dao.BookDao;
import com.mphasis.bookreselling.Dao.BookDaoImpl;

public class BookBo {

	private static final List<Book> BookList = null;

	public void create(Book book) {
		BookDao bookDao=new BookDaoImpl();
	    bookDao.create(book);
		
	}

	public  List<Book> read(int bookid) {
		BookDao bookDao=new BookDaoImpl();
		List<Book> BookList=bookDao.read(bookid);
		return BookList;
	}
	
	public  void update (int bookid,String status) {
		BookDao bookDao=new BookDaoImpl();
		bookDao.update(bookid,status);
		
	}

	public   void delete(int bookid) {
		BookDao bookDao=new BookDaoImpl();
		bookDao.delete(bookid);
		
	}

}


