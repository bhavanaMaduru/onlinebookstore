package com.mphasis.bookreselling.Dao;

import java.util.List;

import com.mphasis.bookreslling.bean.Registration;

public interface RegistrationDao {
	
	public void create(Registration r);
	public List<Registration> read(int sno);
	public void update(int sno, String emailid);
	public  void delete(int sno);
}
