package com.mphasis.bookreslling.bo;

import java.util.List;

import com.mphasis.bookreslling.bean.Admin;
import com.mphasis.bookreselling.Dao.AdminDao;
import com.mphasis.bookreselling.Dao.AdminDaoImpl;

public class AdminBo {

	public void create(Admin admin) {
		AdminDao adminDao=new AdminDaoImpl();
	    adminDao.create(admin);
		
	}

	public  List<Admin> read(int userid) {
		AdminDao adminDao=new AdminDaoImpl();
		List<Admin> AdminList=adminDao .read(userid);
		return AdminList;
	}
	
	public  void update (int userid,String status) {
		AdminDao adminDao=new AdminDaoImpl();
		adminDao.update(userid,status);
		
	}

	public   void delete(int userid) {
		AdminDao adminDao=new AdminDaoImpl();
		adminDao.delete(userid);
		
	}

}


